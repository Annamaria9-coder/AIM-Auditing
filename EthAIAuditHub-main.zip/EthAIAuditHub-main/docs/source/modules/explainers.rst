==========
Explainers
==========

:mod:`aif360.explainers`
========================

.. automodule:: aif360.explainers
    :no-members:
    :no-inherited-members:

.. currentmodule:: aif360

.. autosummary::
   :toctree: generated/
   :template: class.rst

   explainers.MetricTextExplainer
   explainers.MetricJSONExplainer
